package tn.iit.playerteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayerTeamApplicationTests {

    @Test
    void contextLoads() {
    }

}
